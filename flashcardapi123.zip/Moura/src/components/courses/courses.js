import React from "react";

import { Row } from 'react-materialize';

import { NavLink} from 'react-router-dom'

import Course from "./course";


const Courses = (props) => {
  return (
    <div>
      <Row>
        <div class="row">
          <div class="rowc">
            <h5>Cursos</h5>
            {props.coursesData.map(course => (
              <Course 
                course={course} />
            ))}
          </div>
          </div>
      </Row>
      <NavLink to="/forms">
        <a class="btn-floating btn-large waves-effect waves-light red"><i class="material-icons">add</i></a>
      </NavLink>
    </div>
  )
};

export default Courses;